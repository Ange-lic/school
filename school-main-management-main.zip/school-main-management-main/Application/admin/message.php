<?php
include('include/admin_navbar.php');

?>




<table class="table table-bordered" cellspacing="0" cellpadding="0" border="0">
    <tbody>
        <tr class="gradeA">
            <td width="100">SUNDAY</td>
            <td>
            </td>
        </tr>
        <tr class="gradeA">
            <td width="100">MONDAY</td>
            <td>
                <div class="btn-group">
                    <button class="btn btn-info dropdown-toggle" data-toggle="dropdown">
                        English (9-9) </button>
                </div>
            </td>
        </tr>
        <tr class="gradeA">
            <td width="100">TUESDAY</td>
            <td>
            </td>
        </tr>
        <tr class="gradeA">
            <td width="100">WEDNESDAY</td>
            <td>
            </td>
        </tr>
        <tr class="gradeA">
            <td width="100">THURSDAY</td>
            <td>
                <div class="btn-group">
                    <button class="btn btn-info dropdown-toggle" data-toggle="dropdown">
                        English (10-12) </button>
                </div>
            </td>
        </tr>
        <tr class="gradeA">
            <td width="100">FRIDAY</td>
            <td>
            </td>
        </tr>
        <tr class="gradeA">
            <td width="100">SATURDAY</td>
            <td>
            </td>
        </tr>
    </tbody>
</table>